library(shiny)
library(ggplot2)
library(leaflet)
library(dplyr)

# Loading the dataset
data <- read.csv("Victoria_Accident_Data_FIT5147S12024PE2v2.csv")

# Static VIS 1 : Data transformations for SPEED_ZONE and LIGHT_CONDITION_DESC
data_transformed_vis1 <- reactive({
  data %>%
    group_by(SPEED_ZONE, LIGHT_CONDITION_DESC) %>%
    summarise(accidents = n(), .groups = 'drop') %>%
    mutate(SPEED_ZONE = as.factor(SPEED_ZONE))
})

# Grouping top 4 Speed zones   
top_speed_zones <- reactive({
  data_transformed_vis1() %>%
    group_by(SPEED_ZONE) %>%
    summarise(total_accidents = sum(accidents)) %>%
    top_n(4, total_accidents) %>%
    pull(SPEED_ZONE)
})

# Static VIS 2: Data transformations for SPEED_ZONE count With respect to hours
data_transformed_vis2 <- reactive({
  data %>%
    filter(SPEED_ZONE %in% top_speed_zones()) %>%
    group_by(SPEED_ZONE, hour = format(as.POSIXct(ACCIDENT_TIME, format="%H:%M:%S"), "%H")) %>%
    summarise(accidents = n(), .groups = 'drop') %>%
    mutate(hour = as.numeric(hour), SPEED_ZONE = as.factor(SPEED_ZONE))
})

# UI layout construction. 
ui <- fluidPage(
  # Title
  titlePanel("Vehicle Accident Data Visualizations"),
  
  # Description for STATIC VIS 1 and 2
  fluidRow(
    column(6, 
           plotOutput("vis1"),
           p("This bar chart illustrates the frequency of accidents across different speed zones, highlighting each zone with colors corresponding to various lighting conditions. It's clear from the chart that the majority of accidents happen during daylight, particularly in areas where speed limits range from 60 to 80 mph.")
    ),
    column(6, 
           plotOutput("vis2"),
           p("This visualization represents the number of accidents per hour in the top speed zones. The chart illustrates the hourly distribution of accidents across different speed zones. It shows that accidents peak during the midday hours, particularly in the 60 and 80 speed zones, where the bars reach their maximum height. As the day transitions into evening, there is a noticeable decline in the number of accidents in all speed zones.")
    )
  ),
  
  # Visualsing MAP using Leaflet
  fluidRow(
    column(12, 
           leafletOutput("map"),
           p("The map above displays the location of accidents, color-coded by light conditions, with details on the severity, type, and conditions of the accidents. The serverity of the accidents is differentiated by the radius of the circle. Bigger the circle radius higher the severity of the accident.Majority of the accidents are in during the day"),
           checkboxGroupInput("mapFilter", "Filter Map by Light Condition:",
                              choices = c("Day" = "Day", "Dusk/Dawn" = "Dusk/Dawn", "Other" = "Other"),
                              selected = c("Day", "Dusk/Dawn", "Other"))
    )
  ),
  
  # Data source
  p("Data source: Victoria_Accident_Data_FIT5147S12024PE2v2.csv | 
    Resources: https://afit-r.github.io/dplyr, 
              https://r4ds.had.co.nz/transform.html,  
              https://youtu.be/bWEhGqiVQOk?si=QHXdP0hu0j9RirHl, 
              https://shiny.posit.co/r/getstarted/shiny-basics/lesson6/")
)

# Server function
server <- function(input, output) {
  # Defining constant color palette for checklist
  light_conditions_colors <- c(
    "Day" = "#87CEEB",
    "Dusk/Dawn" = "#FFDF00",
    "Other" = "#3Eb489"
  )
  
  # Reactive expression for filtered data for the map, with light conditions
  mapData <- reactive({
    data %>%
      mutate(LIGHT_CONDITION_DESC = ifelse(LIGHT_CONDITION_DESC %in% c("Day", "Dusk/Dawn"), 
                                           LIGHT_CONDITION_DESC, 
                                           "Other")) %>%
      filter(LIGHT_CONDITION_DESC %in% input$mapFilter)
  })
  
  #  VIS 1 Plot
  output$vis1 <- renderPlot({
    ggplot(data_transformed_vis1(), aes(x = SPEED_ZONE, y = accidents, fill = LIGHT_CONDITION_DESC)) +
      geom_bar(stat = "identity", position = "stack") +
      labs(title = "Accidents by Light Condition and Speed Zone", x = "Speed Zone", y = "Number of Accidents") +
      theme_minimal()
  })
  
  # VIS 2 Plot
  output$vis2 <- renderPlot({
    ggplot(data_transformed_vis2(), aes(x = hour, y = accidents, fill = SPEED_ZONE)) +
      geom_bar(stat = "identity", position = "dodge") +
      labs(title = "Accidents Per Hour in Top Speed Zones", x = "Hour", y = "Number of Accidents") +
      theme_minimal()
  })
  
  #  map visuals with circle markers and checklist with color legends.. 
  output$map <- renderLeaflet({
    pal <- colorFactor(palette = light_conditions_colors, domain = c("Day", "Dusk/Dawn", "Other"))
    
    leaflet(mapData()) %>%
      addProviderTiles(providers$CartoDB.Positron) %>%
      setView(lng = 145.465783, lat = -38.482461, zoom = 10) %>%
      addCircleMarkers(~LONGITUDE, ~LATITUDE,
                       radius = ~4 * (4 - SEVERITY_RANK), 
                       color = ~pal(LIGHT_CONDITION_DESC),
                       opacity = 0.7,
                       popup = ~paste("Date: ", ACCIDENT_DATE,
                                      "<br>Type: ", ACCIDENT_TYPE_DESC,
                                      "<br>Light: ", LIGHT_CONDITION_DESC,
                                      "<br>Road: ", ROAD_GEOMETRY_DESC,
                                      "<br>Speed Zone: ", as.character(SPEED_ZONE)),
                       group = "Accidents") %>%
      addLegend("bottomright", pal = pal, values = ~LIGHT_CONDITION_DESC,
                title = "Light Condition",
                opacity = 1)
  })
}

# App Connection 
shinyApp(ui = ui, server = server)
